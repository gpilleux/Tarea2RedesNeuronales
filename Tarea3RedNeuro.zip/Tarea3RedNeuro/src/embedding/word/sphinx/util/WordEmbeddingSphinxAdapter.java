package embedding.word.sphinx.util;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.apache.commons.lang3.StringUtils;

import org.apache.log4j.Logger;
import org.sphx.api.SphinxException;

public class WordEmbeddingSphinxAdapter {

	private static Logger logger = Logger.getLogger(WordEmbeddingSphinxAdapter.class);
	
	private WordEmbeddingSphinxAdapter(){
		// use in static way..
	}
	
	private static Connection getConnection()
			throws SphinxException {
		String userName = "root";
		String password = "";
		String url = "jdbc:mysql://localhost/wordembedding";
		try {
			Class.forName("com.mysql.jdbc.Driver").newInstance();
			return DriverManager.getConnection(url, userName, password);
		} catch (Exception e) {
			throw new SphinxException("could not get connection");
		}
	}
	
	public static List<String> getWordsVectorList(String[] sentenceWords)
			throws SphinxException {
		
		List<String> wordsVectorList = new ArrayList<String>();
		
		if (sentenceWords == null || sentenceWords.length == 0){
			logger.error("Sentence with no words, returning empty list");
			return wordsVectorList; 
		}
		
		
		Connection connection = null;
		CallableStatement callableStatement = null;
		try {
			connection = getConnection();
			callableStatement = connection.prepareCall("{ call search_address_book(?)}"); //CREATE PROCEDURE
			callableStatement.setString(1, StringUtils.join(sentenceWords, ","));
			callableStatement.execute();
			ResultSet resultSet = callableStatement.getResultSet();
			prepareResults(resultSet, wordsVectorList);
			connection.close();
		} catch (SQLException e) {
			logger.error("Problem connecting MYSQL - " + e.getMessage());
			throw new SphinxException(e.getMessage());
		} catch (SphinxException e) {
			logger.error("Problem connecting MYSQL - " + e.getMessage());
			throw e;
		} finally{
			if(connection != null){
				try {
					connection.close();
				} catch (SQLException e) {
					logger.error("Problem closing conection - " + e.getMessage());
					e.printStackTrace();
				}
			}
		}
		//int wordsFound = sentenceWords.length;
		// en algun momento : if(word not found) wordsFound--;
		
		// return [wordsVectorList, wordsFound];
		return wordsVectorList;
	}
	
	/*
	 * Sets the representing vector of each word of the sentence in wordsVectorList
	 * probably 'void' is a problem -> return List<String>
	 */
	private static void prepareResults(ResultSet resultSet,
			List<String> wordsVectorList) throws SQLException {
		while (resultSet.next()) {
			wordsVectorList.add(resultSet.getString("vector"));
		}
	}
	
	/*
	 private static List<String> prepareResults(ResultSet resultSet) throws SQLException {
	 	List<String> wordsVectorList = new ArrayList<String>();
		while (resultSet.next()) {
			wordsVectorList.add(resultSet.getString("vector"));
		}
		return wordsVectorList;
	}
	*/
	
	
	
}
