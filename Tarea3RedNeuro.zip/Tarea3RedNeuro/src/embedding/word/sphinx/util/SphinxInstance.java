package embedding.word.sphinx.util;

import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;
import org.sphx.api.SphinxClient;
import org.sphx.api.SphinxException;
import org.sphx.api.SphinxMatch;
import org.sphx.api.SphinxResult;
/*
 * maybe not usefull !
 */
/**
 * Instance that will parse our free text and provide the results.
 * 
 */
public class SphinxInstance {

	private static String SPHINX_HOST = "localhost";
	private static String SPHINX_INDEX = "wordEmbeddingIndex";
	private static int SPHINX_PORT = 9312;

	private static SphinxClient sphinxClient;
	private static Logger logger = Logger.getLogger(SphinxInstance.class);

	static {
		sphinxClient = new SphinxClient(SPHINX_HOST, SPHINX_PORT);
	}
	
	public static List getRepresentingVectors(String sentence) throws SphinxException{
		List repvectors = new ArrayList();
		
		try{
			sphinxClient.SetMatchMode(SphinxClient.SPH_MATCH_EXTENDED2);
			sphinxClient.SetSortMode(SphinxClient.SPH_SORT_RELEVANCE, "");
			SphinxResult result = sphinxClient.Query("SELECT * FROM wordEmbeddingIndex WHERE MATCH('"+sentence+"')", SPHINX_INDEX, "buidling query");
			
			SphinxMatch[] matches = result.matches;
			for (SphinxMatch match : matches) {
				repvectors.add(String.valueOf(match.docId));
			}
			
		} catch (SphinxException e) {
			throw e;
		}
		
		return repvectors;
	}
	
}
