package embedding.word.sphinx.util;

import java.io.File;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import org.sphx.api.SphinxException;

public class MainTest {
	
	public static List<Double> stringToList(String str){
		List<Double> dbList = new ArrayList<Double>();
		String[] strArray = str.split(" ");
		for(String s : strArray){
			dbList.add(Double.parseDouble(s));
		}
		return dbList;
	}

	public static void main(String[] args) throws SphinxException {
		List<List<Double>> orac_cl = new ArrayList<List<Double>>();
		List<List<Double>> orac_arg = new ArrayList<List<Double>>();
		
		List<Double> expected_cl = new ArrayList<Double>();
		List<Double> expected_arg = new ArrayList<Double>();
		
		String linea = null;
		
		Scanner scan_cl = null;
		try{
			scan_cl = new Scanner(new File("C:/Users/GPG/workspace/Tarea3RedNeuro/cl_ponderados.txt"));//, "UTF-8");
			/*
			String line1 = scan_cl.nextLine();
			String line2 = scan_cl.nextLine();
			*/
			String line_cl;
			String expStr_cl;
			int i = 0;
			while (scan_cl.hasNextLine()) {
				i++;
				linea = scan_cl.nextLine();
				if(linea.length() > 2){
					expStr_cl = linea.split("|", 2)[0];
					line_cl = linea.split("|", 2)[1].replace("|", "");
					//System.out.println(stringToList(line_cl));
					orac_cl.add(stringToList(line_cl));
					expected_cl.add(Double.parseDouble(expStr_cl));
				}
				//System.out.println("cl " + expStr_cl);
				//System.out.println("cl " + stringToList(line_cl).size());
			}
			System.out.println(i);
			System.out.println(orac_cl.size());
		}catch(Exception e){
			System.out.println(e);
			System.out.println(linea.length());
		}
		finally{
			scan_cl.close();
		}

	}

}
