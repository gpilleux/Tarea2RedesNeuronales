package tarea3;

import java.io.File;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Scanner;

public class WordsToDb {

	public static void main(String[] args) {
		
		try{
			Connection conn = DriverManager.getConnection("jdbc:mysql://localhost/wordembedding", "root", "");
			
			Statement stm = conn.createStatement();
			
			
			
			Scanner scan = null;
			System.out.println("Starting...");
			
			try{
				scan = new Scanner(new File("C:/Users/GPG/Desktop/Redes Neuronales/Tareas/Tarea3/fasttext-sbwc.3.6.e20.vec"), "UTF-8");
				
				String firstLine = scan.nextLine();
				int numbWords = Integer.parseInt(firstLine.split(" ")[0]);
				int dims = Integer.parseInt(firstLine.split(" ")[1]);
				
				System.out.println(numbWords + " " + dims);
				
				int n = 0;
				while(scan.hasNextLine()){
					n++;
					if(n==100000){
						System.out.println(1.0/7*100 + "%");
					}else if(n==400000){
						System.out.println(4.0/7*100 + "%");
					}
					String line = scan.nextLine();
					
					String[] splitLine = line.split(" ", 2);
					String pal = splitLine[0];
					String vect = splitLine[1];
					//System.out.println(vect.length());
					//List<Double> vect = parseStringtoDoubleArray(strList);
					//map.put(pal, strList);
					String sql = "INSERT INTO palabras "
							+ " (palabra, vector) " 
							+ " values ('"+ pal +"', '"+ vect +"')";
					
					stm.executeUpdate(sql);
					
					//System.out.println(pal);
				}
				System.out.println("Insert Completed");
			
				
				
				
				
			}catch(Exception e){
				System.out.println(e);
			}
			finally{
				scan.close();
			}
			
			
			/*
			ResultSet rs = stm.executeQuery("SELECT * FROM palabras");
			
			while(rs.next()){
				System.out.println(rs.getString("palabra") + " " + rs.getString("vector"));
			}
			*/
			
		}catch(Exception e){
			e.printStackTrace();
		}

	}

}
