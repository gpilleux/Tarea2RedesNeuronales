package tarea3;
 

import java.io.File;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Scanner;

import networks.NeuralNetwork;

public class EmbeddingTrainer {
	
	public static List<Double> stringToList(String str){
		List<Double> dbList = new ArrayList<Double>();
		String[] strArray = str.split(" ");
		for(String s : strArray){
		//for(int i=0; i<strArray.length; i++){
			dbList.add(Double.parseDouble(s));
		}
		return dbList;
	}

	public static void main(String[] args) {
		List<List<Double>> orac_cl = new ArrayList<List<Double>>();
		List<List<Double>> orac_arg = new ArrayList<List<Double>>();
		
		List<Double> expected_cl = new ArrayList<Double>();
		List<Double> expected_arg = new ArrayList<Double>();
		
		Scanner scan_cl = null;
		Scanner scan_arg = null;
		
		//consult words from oraciones.txt
		
		try{
			scan_cl = new Scanner(new File("C:/Users/GPG/workspace/Tarea3RedNeuro/cl_ponderados.txt"));//, "UTF-8");
			/*
			String line1 = scan_cl.nextLine();
			String line2 = scan_cl.nextLine();
			*/
			String line_cl;
			String expStr_cl;
			int i = 0;
			while (scan_cl.hasNextLine()) {
				i++;
				String linea = scan_cl.nextLine();
				if(linea.length() > 2){
					expStr_cl = linea.split("|", 2)[0];
					line_cl = linea.split("|", 2)[1].replace("|", "");
					//System.out.println(stringToList(line_cl));
					orac_cl.add(stringToList(line_cl));
					expected_cl.add(Double.parseDouble(expStr_cl));
				}
				
				//System.out.println("cl " + expStr_cl);
				//System.out.println("cl " + stringToList(line_cl).size());
			}
			System.out.println("lines cl leidas " + i);
		}catch(Exception e){
			System.out.println(e);
		}
		finally{
			scan_cl.close();
		}
		try{			
			scan_arg = new Scanner(new File("C:/Users/GPG/workspace/Tarea3RedNeuro/arg_ponderados.txt"));
			
			String line_arg;
			String expStr_arg;
			int j=0;
			while (scan_arg.hasNextLine()) {
				j++;
				String linea = scan_arg.nextLine();
				if(linea.length() > 2){
					expStr_arg = linea.split("|", 2)[0];
					line_arg = linea.split("|", 2)[1].replace("|", "");
					
					orac_arg.add(stringToList(line_arg));
					expected_arg.add(Double.parseDouble(expStr_arg));
				}
				//System.out.println("arg " + expStr_arg);
				//System.out.println("arg " + stringToList(line_arg).size());
			}
			System.out.println("lines arg leidas " + j);
		}catch(Exception e){
			System.out.println(e);
		}
		finally{
			scan_arg.close();
		}
		
		System.out.println("lineas cl correctas " + orac_cl.size());
		System.out.println("lineas arg correctas " + orac_arg.size());
		
		NeuralNetwork wordEmbeddingNetwork = new NeuralNetwork(300, 2, 1);
		
		double learningRate = 0.3;
		int epocs = 10;
		
		if(orac_cl != null && orac_arg != null){
			System.out.println("Found words..");
			System.out.println("...Trainning...");
			
			int min_perc = Math.min((int)(0.8*orac_cl.size()), (int)(0.8*orac_arg.size()));
			
			for(int i=0; i<epocs; i++){
				for(int j=0; j<min_perc; j++){
					wordEmbeddingNetwork.trainNetwork(orac_cl.get(j), Arrays.asList(expected_cl.get(j)), learningRate);
					wordEmbeddingNetwork.trainNetwork(orac_arg.get(j), Arrays.asList(expected_arg.get(j)), learningRate);
				}
			}
			
			System.out.println("Trainned with " + min_perc + " instances");
			
			System.out.println("...Testing...");
			System.out.println("Assertion:");
			
			//Testing Chileans
			int assert_cl = 0;
			for(int i=min_perc; i<orac_cl.size(); i++){
				wordEmbeddingNetwork.feedNetwork(orac_cl.get(i));
				double answ = wordEmbeddingNetwork.getOutput().get(0);
				//System.out.println("answ: " + answ);
				if(answ <= 0.5)
					assert_cl++;
				wordEmbeddingNetwork.clearInputList();
			}
			/*
			System.out.println(assert_cl);
			System.out.println(orac_cl.size()-min_perc);
			*/
			System.out.println("Chileans " + 100.0*assert_cl/(orac_cl.size()-min_perc) + "%");
			
			//Testing Arg
			int assert_arg = 0;
			for(int i=min_perc; i<orac_arg.size(); i++){
				wordEmbeddingNetwork.feedNetwork(orac_arg.get(i));
				double answ = wordEmbeddingNetwork.getOutput().get(0);
				if(answ >= 0.5)
					assert_arg++;
				wordEmbeddingNetwork.clearInputList();
			}
			/*
			System.out.println(assert_arg);
			System.out.println(orac_arg.size()-min_perc);
			*/
			System.out.println("Argentinians " + 100.0*assert_arg/(orac_arg.size()-min_perc) + "%");
			//System.out.println(min_perc);
			
			
		}
			
			System.out.println("...Finished");
	}
		
		

}


