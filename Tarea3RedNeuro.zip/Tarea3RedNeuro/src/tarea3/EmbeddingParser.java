package tarea3;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Scanner;


public class EmbeddingParser {
	
	private static Map map = new HashMap<String, List<String>>();
	
	public static List<Double> parseStringtoDoubleArray(List<String> strArray){
		List<Double> result = new ArrayList<Double>();
		for(int i=0; i<strArray.size(); i++){
			result.add(Double.parseDouble(strArray.get(i)));
		}
		return result;
	}
	
	public static double cosineSimilarity(List<Double> vectorA, List<Double> vectorB) {
	    double dotProduct = 0.0;
	    double normA = 0.0;
	    double normB = 0.0;
	    for (int i = 0; i < vectorA.size(); i++) {
	        dotProduct += vectorA.get(i) * vectorB.get(i);
	        normA += Math.pow(vectorA.get(i), 2);
	        normB += Math.pow(vectorB.get(i), 2);
	    }   
	    return dotProduct / (Math.sqrt(normA) * Math.sqrt(normB));
	}

	public static void main(String[] args) {
		Scanner scan = null;
		System.out.println("Starting...");
		try{
			scan = new Scanner(new File("C:/Users/GPG/Desktop/Redes Neuronales/Tareas/Tarea3/fasttext-sbwc.3.6.e20.vec"), "UTF-8");
			
			String firstLine = scan.nextLine();
			int numbWords = Integer.parseInt(firstLine.split(" ")[0]);
			int dims = Integer.parseInt(firstLine.split(" ")[1]);
			
			System.out.println(numbWords + " " + dims);
			
			int n = 0;
			while(scan.hasNextLine() && n < 2){
				n++;
				String line = scan.nextLine();
				
				/*
				List<String> strList = new ArrayList<String>(Arrays.asList(line.split(" ")));
				String pal = strList.get(0);
				strList.remove(0);
				*/
				String[] splitLine = line.split(" ", 2);
				String pal = splitLine[0];
				String vect = splitLine[1];
				//List<Double> vect = parseStringtoDoubleArray(strList);
				//map.put(pal, strList);
				System.out.println(pal);
				System.out.println(vect);
			}
			
			
			System.out.println(map.size());
			
			/*
			
			BufferedWriter writer = null;
			try{
				File logFile = new File("palabras.txt");
				System.out.println(logFile.getCanonicalPath());
				
				writer = new BufferedWriter(new FileWriter(logFile));
				
				Iterator<String> itr2 = map.keySet().iterator();
				while (itr2.hasNext()) {
				    writer.write(itr2.next());
				    writer.newLine();
				}
				
			} catch (Exception e) {
	            e.printStackTrace();
	        } finally {
	            try {
	                // Close the writer regardless of what happens...
	                writer.close();
	            } catch (Exception e) {
	            }
	        }
	        
	        */
			/*
			System.out.println("Terminado...");
			System.out.println("...Calculando similitud...");
			
			List<Double> hola = parseStringtoDoubleArray((List<String>)map.get("de"));
			List<Double> chao = parseStringtoDoubleArray((List<String>)map.get("la"));
			
			
			System.out.println(hola);
			System.out.println(chao);
			System.out.println(cosineSimilarity(hola, chao));
			*/
		}
		catch(Exception e){
			System.out.println(e);
		}
		finally{
			scan.close();
		}
		

	}

}

