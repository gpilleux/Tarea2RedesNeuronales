package tarea3;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import embedding.word.sphinx.util.WordEmbeddingSphinxAdapter;

/*
 * Calculates the representing vector for each sentence
 */

public class WordConsulter {
	
	public static List<Double> parseStringtoDoubleArray(List<String> strArray){
		List<Double> result = new ArrayList<Double>();
		for(int i=0; i<strArray.size(); i++){
			result.add(Double.parseDouble(strArray.get(i)));
		}
		return result;
	}
	
	public static List<Double> stringToDoubleArray(String[] strArray){
		List<Double> result = new ArrayList<Double>();
		
		for(int i=0; i<strArray.length; i++){
			result.add(Double.parseDouble(strArray[i]));
		}
		
		return result;
	}
	
	public static double cosineSimilarity(List<Double> vectorA, List<Double> vectorB) {
	    double dotProduct = 0.0;
	    double normA = 0.0;
	    double normB = 0.0;
	    for (int i = 0; i < vectorA.size(); i++) {
	        dotProduct += vectorA.get(i) * vectorB.get(i);
	        normA += Math.pow(vectorA.get(i), 2);
	        normB += Math.pow(vectorB.get(i), 2);
	    }   
	    return dotProduct / (Math.sqrt(normA) * Math.sqrt(normB));
	}
	
	public static List<Double> addVectors(List<Double> promOrc, List<Double> dbList) {
		for(int i=0; i<dbList.size(); i++){
			promOrc.set(i, promOrc.get(i) + dbList.get(i));
		}
		return promOrc;
	}
	
	public static List<Double> vectorDivideBy(List<Double> promOrc, int length) {
		for(int i=0; i<promOrc.size(); i++){
			promOrc.set(i, 1.0*promOrc.get(i)/length);
		}
		return promOrc;
	}
	
	public static String doubleListToString(List<Double> dbList){
		String res = "";
		for(int i=0; i<dbList.size(); i++){
			if(i==0)
				res += String.valueOf(dbList.get(i));
			else
				res += " " + String.valueOf(dbList.get(i));
		}
		return res;
	}
	
	public static List<String[]> listsOfString(List<String> strList){
		List<String[]> lists = new ArrayList<String[]>();
		for(String str : strList){
			lists.add(str.split(" "));
		}
		return lists;
	}
	
	public static List<Double> meanOfStrList(List<String> strList){
		List<String[]> strListVect = listsOfString(strList);
		List<Double> vectorMean = new ArrayList<Double>();
		for (int k = 0; k<300; k++) {
			vectorMean.add((double) 0);
		}
		//add every j'th component of every rep vector (of every word) to the j'th of vectorMean
		for(int i=0; i<strListVect.size(); i++){
			for(int j=0; j<strListVect.get(i).length; j++){
				vectorMean.set(j, vectorMean.get(j) + Double.parseDouble(strListVect.get(i)[j]));
			}
		}
		//calculate mean for every component
		for(int i=0; i<strList.size(); i++){
			vectorMean.set(i, 1.0*vectorMean.get(i)/strList.size());
		}
		
		return vectorMean;
	}
	
	public static void main(String[] args) {
		
		try{
			System.out.println("Starting...");
			Connection conn = DriverManager.getConnection("jdbc:mysql://localhost/wordembedding", "root", "");
			
			//List<List<Double>> allVecReps = new ArrayList<List<Double>>();
			
			//read sentences from tweeter database
			File inputFile = new File("C:/Users/GPG/workspace/Tarea3RedNeuro/cl.txt");
			BufferedReader reader = new BufferedReader(new FileReader(inputFile));
			
			int numOraciones = 3; 
			
			String[] oraciones = new String[numOraciones];
			
			for(int i=0; i<numOraciones; i++){
				String orc = reader.readLine().replaceAll(",", "").replaceAll(";", "").replaceAll(":", "");
				orc = orc.replaceAll(" +", " ").replaceAll("(?s)<U+.*?>", "");
				orc = orc.replace("�", "");
				orc = orc.trim();
				oraciones[i] = orc;
			}
			
			reader.close();
			
			BufferedWriter writer = null;
			try{
				File logFile = new File("oraciones.txt");
				System.out.println(logFile.getCanonicalPath());
				
				writer = new BufferedWriter(new FileWriter(logFile));
				
				for(int j=0; j<oraciones.length; j++){
					
					List<Double> promOrc = new ArrayList<Double>();
					for (int k = 0; k<300; k++) {
						promOrc.add((double) 0);
					}
					
					
					String orc = oraciones[j];
					System.out.println(orc);
					
					String[] orcSplt = orc.split(" ");
					
					int wordsFound = orcSplt.length;
					
					//to the WordEmbeddingSphinxAdapter: I provide it a sentence and it 
					//returns a list of the representing vectors for each word
					List<String> sntcRepVects = WordEmbeddingSphinxAdapter.getWordsVectorList(oraciones[j].split(" "));
					List<Double> sntcMeanVec = meanOfStrList(sntcRepVects);
					// ver los casos en que no encuentra la palabra
					
					
					/*
					for(int i=0; i<orcSplt.length; i++){
						Statement stm = conn.createStatement();
						//query over sphinx
						ResultSet rs = stm.executeQuery("SELECT vector FROM palabras WHERE palabra = '"+ orcSplt[i] +"'");
						if(rs.next()){
							String[] splt = rs.getString("vector").split(" ");
							List<Double> dbList = stringToDoubleArray(splt);
							//System.out.println(dbList.size());
							promOrc = addVectors(promOrc, dbList);
							System.out.print(" found ");
						}else{
							wordsFound--;
							System.out.println(orcSplt[i] + " Not found" + " " + wordsFound);
						}
					}
					*/
					if(wordsFound > 0){
						promOrc = vectorDivideBy(promOrc, wordsFound);
						String strToFile = "0|" + doubleListToString(promOrc);
						writer.write(strToFile);
					    writer.newLine();
					}else{
						System.out.println("Sentence too short");
					}
				}
				
				
			} catch (Exception e) {
	            e.printStackTrace();
	        } finally {
	            try {
					// Close the writer regardless of what happens...
	                writer.close();
	            } catch (Exception e) {
	            }
	        }
			
			System.out.println("...Finished");
		
		}catch(Exception e){
			e.printStackTrace();
		}

	}

	

		
}




